// Assinatura da função cauchy
float cauchy(float num1);

// Assinatura da função gumbel
float gumbel(float num1, float num2, float num3);

// Assinatura da função laplace
float laplace(float num1, float num2, float num3);