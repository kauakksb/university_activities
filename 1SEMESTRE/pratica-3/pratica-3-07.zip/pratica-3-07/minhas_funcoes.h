// Função que soma 1 ao número inserido
void soma1(int *num);

// Função que troca os valores de duas variáveis através dos seus ponteiros
void troca(float *end_valor1, float *end_valor2);

// Função que retorna apenas o número do DDD de um telefone
int ddd(long long int tel);

